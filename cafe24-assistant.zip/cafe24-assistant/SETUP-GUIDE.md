# 카페24 쇼핑몰 어시스턴트 — 설정 가이드

## 전체 구조

```
┌─────────────────────────────────────────────────────────────┐
│ 사전 준비 (서비스 제공자 1회)                                 │
│                                                              │
│  1. 카페24 개발자센터에서 앱 등록                              │
│  2. redirect_uri = 정적 콜백 페이지 URL                       │
│  3. app.json에 client_id, client_secret 설정                  │
│  4. 콜백 페이지(callback/index.html) 배포                     │
│  5. OpenClaw 서버에 파일 배치                                 │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│ 고객 온보딩 (텔레그램 대화만으로 완결)                         │
│                                                              │
│  고객: "안녕"                                                │
│  봇: 쇼핑몰 이름, mall_id 질문                               │
│  봇: 앱 설치 링크 전송                                       │
│  고객: 링크 탭 → 카페24 로그인 → "허용" 클릭                  │
│  고객: 리다이렉트된 URL 통째로 복사 → 텔레그램에 붙여넣기      │
│  봇: code 추출 → 토큰 교환(아웃바운드) → 저장 → 완료          │
│  봇: 기능 선택 → Cron 등록 → 사용 시작                       │
└─────────────────────────────────────────────────────────────┘
```

## 배포 방법

### 방법 A: 텔레그램 대화로 배포 (서버 작업 불필요)

서버에 OpenClaw이 이미 구동 중이고, 텔레그램 봇이 연결된 상태라면:

1. 텔레그램에서 에이전트에게 cafe24-api.py 파일을 첨부 전송
2. "이 파일을 /data/scripts/cafe24-api.py에 저장해줘" 지시
3. SKILL.md, AGENTS.md, SOUL.md, TOOLS.md를 각각 텍스트로 전달하거나 파일 첨부
4. "skills/cafe24-assistant/SKILL.md에 저장해줘" 식으로 지시
5. app.json을 JSON 텍스트로 전달: "이걸 /data/config/app.json에 저장해줘"
6. templates/ 파일도 같은 방식으로 전달

에이전트가 파일을 수신하면 `/data/.openclaw/media/inbound/`에 저장된다.
에이전트에게 원하는 경로로 복사하도록 지시하면 된다.

### 방법 B: 서버 사이드 배포 (개발자 작업)

DEPLOY-SERVER-SIDE.md 참조.
Containerfile에 skeleton으로 포함시키는 방식 — 서버 배포 시 자동 적용.

## 파일 구조

```
soul/
├── SOUL.md              에이전트 정체성 (쇼핑몰 어시, 러프한 톤)
├── AGENTS.md            온보딩 플로우 + 운영 규칙 + Cron 프리셋
└── TOOLS.md             Cafe24 API 레퍼런스

skills/cafe24-assistant/
└── SKILL.md             카페24 API 연동 스킬 (OAuth + 운영 워크플로우)

config/
├── app.json             카페24 앱 인증 (서비스 제공자가 설정)
├── store.example.json   쇼핑몰 설정 템플릿 (에이전트가 자동 생성)
└── tokens.example.json  OAuth 토큰 템플릿 (에이전트가 자동 생성)

scripts/
└── cafe24-api.py        API 헬퍼 스크립트

callback/
└── index.html           정적 콜백 페이지 (GitHub Pages 등에 배포)

templates/
├── daily-report.md      일일 리포트 템플릿
└── inventory-alert.md   재고 알림 템플릿
```

---

## 사전 준비 (서비스 제공자 1회)

### 1. 카페24 개발자센터 앱 등록

1. https://developers.cafe24.com 접속 → 개발자 등록
2. [앱 만들기] → 앱 정보 입력:
   - 앱 이름: "쇼핑몰 어시스턴트" (자유)
   - Redirect URI: 콜백 페이지 URL (예: `https://cafe24-connect.pages.dev/callback`)
   - 필요 권한(Scopes):
     - mall.read_order (주문 조회)
     - mall.read_product (상품 조회)
     - mall.read_customer (고객 조회)
     - mall.read_store (쇼핑몰 정보)
     - mall.read_salesreport (매출 통계)
     - mall.read_category (카테고리)
     - mall.read_shipping (배송)
3. 발급된 Client ID, Client Secret 저장

### 2. 콜백 페이지 배포

`callback/index.html`을 정적 호스팅에 배포:
- GitHub Pages, Cloudflare Pages, Vercel, Netlify 등 (무료)
- 배포 URL = 앱 등록 시 설정한 Redirect URI

### 3. app.json 설정

```json
{
  "client_id": "발급받은_Client_ID",
  "client_secret": "발급받은_Client_Secret",
  "redirect_uri": "https://배포한_콜백페이지_URL/callback",
  "scopes": ["mall.read_order", "mall.read_product", ...]
}
```

### 4. OpenClaw 서버에 파일 배치

```bash
# SSH 접속 후 컨테이너 내부에서:

# 워크스페이스 파일
cp soul/SOUL.md ~/.openclaw/agents/default/SOUL.md
cp soul/AGENTS.md ~/.openclaw/agents/default/AGENTS.md
cp soul/TOOLS.md ~/.openclaw/agents/default/TOOLS.md

# 스킬
cp -r skills/cafe24-assistant/ ~/.openclaw/skills/cafe24-assistant/

# 설정 (app.json만 — store.json, tokens.json은 에이전트가 자동 생성)
mkdir -p /data/config
cp config/app.json /data/config/app.json

# 헬퍼 스크립트
mkdir -p /data/scripts
cp scripts/cafe24-api.py /data/scripts/cafe24-api.py

# 템플릿
cp -r templates/ /data/templates/
```

### 5. Gateway 재시작

```bash
touch /data/.signal-restart
```

---

## OAuth 플로우 상세

```
토큰 교환이 아웃바운드(서버→카페24) 요청이므로
고객 서버의 방화벽 인바운드 정책과 무관하게 동작합니다.

고객 브라우저 → 카페24 (인증+승인)
카페24 → 정적 페이지 (code 전달, 302 redirect)
정적 페이지 → 고객 (URL 표시)
고객 → 텔레그램 (URL 붙여넣기)
에이전트 → 카페24 (code→token 교환, 아웃바운드 POST)
```

---

## 설계 원칙

| 원칙 | 설명 |
|------|------|
| 고객은 텔레그램만 | 서버 접속, 코드 입력, 파일 업로드 없음 |
| 앱은 1개로 전 고객 | 정적 콜백 페이지를 공용 redirect_uri로 사용 |
| 방화벽 무관 | 토큰 교환은 아웃바운드, 콜백은 정적 페이지 |
| 자동 설정 | 에이전트가 store.json, tokens.json, Cron 자동 생성 |
| 자동 갱신 | 12시간마다 토큰 갱신 Cron으로 14일 만료 방지 |

---

## 테스트 체크리스트

### 사전 준비
- [ ] 카페24 개발자센터 앱 등록 완료
- [ ] 콜백 페이지(callback/index.html) 배포 완료
- [ ] app.json에 client_id, client_secret 설정 완료
- [ ] OpenClaw 서버에 파일 배치 완료
- [ ] Gateway 재시작 완료

### 온보딩 테스트
- [ ] 텔레그램에서 첫 대화 시 온보딩 플로우 진입
- [ ] mall_id 수집 정상
- [ ] OAuth 인증 URL 생성 정상
- [ ] 콜백 페이지에서 URL 표시 정상
- [ ] URL 붙여넣기 후 code 추출 정상
- [ ] 토큰 교환 성공 (1분 이내)
- [ ] store-info API 호출로 연결 확인
- [ ] store.json 자동 생성 확인
- [ ] tokens.json 자동 생성 확인

### 운영 테스트
- [ ] "오늘 주문" → 주문 조회 정상
- [ ] "매출 알려줘" → 매출 리포트 정상
- [ ] "재고 확인" → 재고 부족 알림 정상
- [ ] Cron 작업 자동 등록 확인
- [ ] 토큰 자동 갱신 확인
- [ ] 사이트 헬스체크 정상

### 에러 처리 테스트
- [ ] 잘못된 code 입력 시 안내 메시지
- [ ] 1분 초과 code 입력 시 재시도 안내
- [ ] 401 발생 시 자동 토큰 갱신
- [ ] Rate Limit 시 재시도

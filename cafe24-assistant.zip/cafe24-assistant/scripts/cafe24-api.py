#!/usr/bin/env python3
"""
카페24 API 헬퍼 스크립트
OpenClaw 에이전트가 exec로 호출하여 사용.

사용법:
  python3 cafe24-api.py [--mall MALL_ID] [--mask] [--send] COMMAND [ARGS...]

글로벌 옵션:
  --mall MALL_ID    특정 몰 지정 (생략 시 기본 몰 사용)
  --mask            개인정보 마스킹 (전화번호, 주소, 이메일)
  --send            결과를 텔레그램으로 직접 전송

온보딩:
  auth-url {mall_id}                    OAuth 인증 URL 생성
  exchange-code {mall_id} {code}        authorization code → 토큰 교환
  refresh-token                         토큰 갱신
  token-status                          토큰 상태 및 만료일 확인

몰 관리:
  malls list                            등록된 몰 목록
  malls switch {mall_id}                기본 몰 변경
  malls add {mall_id}                   새 몰 등록 (빈 설정 생성)

주문:
  orders [today|yesterday|날짜|시작 끝]  주문 목록 + 요약
  orders-count [today|yesterday|날짜]    주문 건수만
  order-detail {order_id}               주문 상세

매출:
  sales [today|yesterday|week|month|시작 끝]  매출 리포트

상품:
  products [--limit N] [--offset N]     상품 목록
  product-detail {product_no}           상품 상세

재고:
  inventory [threshold]                 재고 부족 상품

고객:
  customers-count                       회원 수
  customer-groups                       등급별 분류
  customer-detail {member_id}           회원 상세

쿠폰:
  coupons-list                          쿠폰 목록
  coupon-create {json_file}             쿠폰 생성 (JSON 파일)

배송:
  shipment-create {order_id} {json_file}  송장 등록 (JSON 파일)
  shipping-carriers                     택배사 목록

게시판:
  boards-list                           게시판 목록
  board-articles {board_no}             게시물 조회

적립금:
  mileage {member_id}                   적립금 조회
  mileage-give {member_id} {amount} {reason}  적립금 지급

모니터링:
  store-info                            쇼핑몰 정보
  healthcheck                           사이트 상태
"""

import sys
import json
import os
import re
import time
import urllib.request
import urllib.error
import urllib.parse
import base64
from datetime import datetime, timedelta
from pathlib import Path

# ──────────────────────────────────────────────────────────
# 설정
# ──────────────────────────────────────────────────────────

CONFIG_DIR = Path("/data/config")
STORES_DIR = CONFIG_DIR / "stores"
APP_FILE = CONFIG_DIR / "app.json"
ACTIVE_FILE = STORES_DIR / "_active.json"
TELEGRAM_CONFIG_FILE = Path("/data/.openclaw/openclaw.json")
TELEGRAM_ALLOWFROM_FILE = Path("/data/.openclaw/credentials/telegram-default-allowFrom.json")
API_VERSION = "2026-03-01"
RATE_LIMIT_DELAY = 0.6  # 초당 2회 제한 대응
MAX_RETRIES = 3

# 글로벌 옵션 (main에서 파싱)
OPTS = {"mall": None, "mask": False, "send": False}


# ──────────────────────────────────────────────────────────
# 설정 로드/저장
# ──────────────────────────────────────────────────────────

def load_app():
    if not APP_FILE.exists():
        fail("app.json not found. Service provider setup required.")
    with open(APP_FILE) as f:
        return json.load(f)


def get_active_mall_id():
    if OPTS["mall"]:
        return OPTS["mall"]
    if ACTIVE_FILE.exists():
        with open(ACTIVE_FILE) as f:
            data = json.load(f)
            return data.get("default_mall_id", "")
    # 레거시: 단일 store.json 방식 호환
    legacy = CONFIG_DIR / "store.json"
    if legacy.exists():
        with open(legacy) as f:
            return json.load(f).get("mall_id", "")
    return ""


def get_store_dir(mall_id):
    d = STORES_DIR / mall_id
    d.mkdir(parents=True, exist_ok=True)
    return d


def load_store(mall_id=None):
    mall_id = mall_id or get_active_mall_id()
    if not mall_id:
        fail("No mall configured. Run onboarding first.")
    store_file = get_store_dir(mall_id) / "store.json"
    if not store_file.exists():
        # 레거시 호환
        legacy = CONFIG_DIR / "store.json"
        if legacy.exists():
            with open(legacy) as f:
                data = json.load(f)
                if data.get("mall_id") == mall_id:
                    return data
        fail(f"store.json not found for mall '{mall_id}'. Run onboarding first.")
    with open(store_file) as f:
        return json.load(f)


def save_store(mall_id, data):
    store_file = get_store_dir(mall_id) / "store.json"
    data["updated_at"] = datetime.now().isoformat()
    with open(store_file, "w") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def load_tokens(mall_id=None):
    mall_id = mall_id or get_active_mall_id()
    if not mall_id:
        fail("No mall configured. Run onboarding first.")
    tokens_file = get_store_dir(mall_id) / "tokens.json"
    if not tokens_file.exists():
        # 레거시 호환
        legacy = CONFIG_DIR / "tokens.json"
        if legacy.exists():
            with open(legacy) as f:
                return json.load(f)
        fail(f"tokens.json not found for mall '{mall_id}'. API auth required.")
    with open(tokens_file) as f:
        return json.load(f)


def save_tokens(mall_id, tokens):
    tokens["last_refreshed_at"] = datetime.now().isoformat()
    tokens_file = get_store_dir(mall_id) / "tokens.json"
    with open(tokens_file, "w") as f:
        json.dump(tokens, f, indent=2, ensure_ascii=False)
    try:
        os.chmod(tokens_file, 0o600)
    except OSError:
        pass


def set_active_mall(mall_id):
    STORES_DIR.mkdir(parents=True, exist_ok=True)
    with open(ACTIVE_FILE, "w") as f:
        json.dump({"default_mall_id": mall_id}, f, indent=2)


# ──────────────────────────────────────────────────────────
# 유틸리티
# ──────────────────────────────────────────────────────────

def fail(message):
    print(json.dumps({"error": message}, ensure_ascii=False))
    sys.exit(1)


def output(data):
    text = json.dumps(data, ensure_ascii=False, indent=2)
    if OPTS["send"]:
        send_telegram(text)
    print(text)


def basic_auth(client_id, client_secret):
    return base64.b64encode(f"{client_id}:{client_secret}".encode()).decode()


def mask_value(value):
    if not OPTS["mask"] or not isinstance(value, str) or not value:
        return value
    # 전화번호: 010-1234-5678 → 010-****-5678
    value = re.sub(r'(\d{2,3})-(\d{3,4})-(\d{4})', r'\1-****-\3', value)
    # 이메일: user@domain.com → u***@domain.com
    value = re.sub(r'([a-zA-Z0-9])[a-zA-Z0-9.]*@', r'\1***@', value)
    # 주소: 4자 이상이면 앞 절반 유지 + ***
    if len(value) > 20 and not re.search(r'[@\d{3}-]', value):
        half = len(value) // 3
        value = value[:half] + "***"
    return value


def mask_dict(d, keys=("buyer_cellphone", "buyer_phone", "buyer_email",
                        "receiver_cellphone", "receiver_phone",
                        "buyer_address1", "buyer_address2",
                        "receiver_address1", "receiver_address2",
                        "buyer_name", "receiver_name")):
    if not OPTS["mask"] or not isinstance(d, dict):
        return d
    for k in keys:
        if k in d and d[k]:
            d[k] = mask_value(str(d[k]))
    return d


def parse_date_range(args):
    today = datetime.now().strftime("%Y-%m-%d")
    if not args or args[0] == "today":
        return today, today
    if args[0] == "yesterday":
        yd = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
        return yd, yd
    if args[0] == "week":
        return (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d"), today
    if args[0] == "month":
        return datetime.now().replace(day=1).strftime("%Y-%m-%d"), today
    if len(args) == 1:
        return args[0], args[0]
    return args[0], args[1]


# ──────────────────────────────────────────────────────────
# API 호출 (Rate Limit + 401 재시도)
# ──────────────────────────────────────────────────────────

def api_call(mall_id, access_token, endpoint, params=None, method="GET", body=None):
    base = f"https://{mall_id}.cafe24api.com/api/v2/admin"
    url = f"{base}/{endpoint}"
    if params:
        query = "&".join(f"{k}={urllib.parse.quote(str(v))}" for k, v in params.items())
        url = f"{url}?{query}"

    data = json.dumps(body).encode() if body else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", f"Bearer {access_token}")
    req.add_header("Content-Type", "application/json")
    req.add_header("X-Cafe24-Api-Version", API_VERSION)

    for attempt in range(MAX_RETRIES):
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                return json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            code = e.code
            body_text = e.read().decode() if e.fp else ""
            if code == 429 and attempt < MAX_RETRIES - 1:
                time.sleep(1 + attempt)
                continue
            return {"error": f"HTTP {code}", "detail": body_text}
        except urllib.error.URLError as e:
            return {"error": f"Connection failed: {e.reason}"}
    return {"error": "Max retries exceeded"}


def api_call_with_retry(mall_id, tokens, endpoint, params=None, method="GET", body=None):
    result = api_call(mall_id, tokens["access_token"], endpoint, params, method, body)
    if isinstance(result, dict) and "error" in result and "401" in str(result.get("error", "")):
        app = load_app()
        ok, new_tokens = do_refresh_token(app, mall_id, tokens)
        if ok:
            result = api_call(mall_id, new_tokens["access_token"], endpoint, params, method, body)
    return result


def api_list_all(mall_id, tokens, endpoint, key, params=None, delay=True):
    """페이지네이션으로 전체 목록 조회"""
    all_items = []
    offset = 0
    limit = 100
    p = dict(params or {})
    p["limit"] = str(limit)
    while True:
        p["offset"] = str(offset)
        result = api_call_with_retry(mall_id, tokens, endpoint, p)
        items = result.get(key, [])
        if not items:
            break
        all_items.extend(items)
        if len(items) < limit:
            break
        offset += limit
        if delay:
            time.sleep(RATE_LIMIT_DELAY)
    return all_items


# ──────────────────────────────────────────────────────────
# 텔레그램 직접 전송
# ──────────────────────────────────────────────────────────

def send_telegram(text):
    try:
        bot_token = ""
        chat_id = ""
        if TELEGRAM_CONFIG_FILE.exists():
            with open(TELEGRAM_CONFIG_FILE) as f:
                cfg = json.load(f)
                bot_token = cfg.get("channels", {}).get("telegram", {}).get("botToken", "")
        if TELEGRAM_ALLOWFROM_FILE.exists():
            with open(TELEGRAM_ALLOWFROM_FILE) as f:
                af = json.load(f)
                ids = af.get("allowFrom", [])
                if ids:
                    chat_id = str(ids[0])
        if not bot_token or not chat_id:
            return
        # 텔레그램 메시지 4096자 제한
        if len(text) > 4000:
            text = text[:4000] + "\n...(truncated)"
        url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
        body = json.dumps({"chat_id": chat_id, "text": text}).encode()
        req = urllib.request.Request(url, data=body, method="POST")
        req.add_header("Content-Type", "application/json")
        urllib.request.urlopen(req, timeout=10)
    except Exception:
        pass  # 실패해도 stdout 출력은 계속


# ──────────────────────────────────────────────────────────
# 토큰 관리
# ──────────────────────────────────────────────────────────

def do_refresh_token(app, mall_id, tokens):
    auth = basic_auth(app["client_id"], app["client_secret"])
    data = f"grant_type=refresh_token&refresh_token={tokens['refresh_token']}".encode()
    req = urllib.request.Request(
        f"https://{mall_id}.cafe24api.com/api/v2/oauth/token",
        data=data, method="POST",
    )
    req.add_header("Authorization", f"Basic {auth}")
    req.add_header("Content-Type", "application/x-www-form-urlencoded")
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            new = json.loads(resp.read().decode())
            tokens["access_token"] = new["access_token"]
            tokens["refresh_token"] = new["refresh_token"]
            tokens["expires_at"] = new.get("expires_at", "")
            tokens["refresh_token_expires_at"] = new.get("refresh_token_expires_at", "")
            save_tokens(mall_id, tokens)
            return True, tokens
    except urllib.error.HTTPError as e:
        return False, {"error": f"Token refresh failed: HTTP {e.code}"}


def check_token_expiry(tokens):
    """refresh_token 만료 임박 여부 확인. 경고 dict 또는 None 반환."""
    rt_expires = tokens.get("refresh_token_expires_at", "")
    if not rt_expires:
        obtained = tokens.get("obtained_at") or tokens.get("last_refreshed_at", "")
        if obtained:
            try:
                dt = datetime.fromisoformat(obtained.replace("Z", "+00:00").split("+")[0])
                rt_expires = (dt + timedelta(days=14)).isoformat()
            except ValueError:
                return None
    if not rt_expires:
        return None
    try:
        exp = datetime.fromisoformat(rt_expires.replace("Z", "+00:00").split("+")[0])
        remaining = (exp - datetime.now()).days
        if remaining <= 2:
            return {"warning": f"refresh_token {remaining}일 후 만료! 즉시 재연동 필요.", "days_remaining": remaining}
        if remaining <= 5:
            return {"warning": f"refresh_token {remaining}일 후 만료 예정. 재연동 준비 필요.", "days_remaining": remaining}
    except ValueError:
        pass
    return None


# ──────────────────────────────────────────────────────────
# 명령어: 온보딩
# ──────────────────────────────────────────────────────────

def cmd_auth_url(args):
    if not args:
        fail("mall_id required")
    mall_id = args[0]
    app = load_app()
    state = base64.urlsafe_b64encode(mall_id.encode()).decode().rstrip("=")
    scopes = ",".join(app["scopes"])
    url = (
        f"https://{mall_id}.cafe24api.com/api/v2/oauth/authorize"
        f"?response_type=code"
        f"&client_id={app['client_id']}"
        f"&state={state}"
        f"&redirect_uri={urllib.parse.quote(app['redirect_uri'], safe='')}"
        f"&scope={urllib.parse.quote(scopes, safe='')}"
    )
    output({"url": url, "mall_id": mall_id})


def cmd_exchange_code(args):
    if len(args) < 2:
        fail("Usage: exchange-code {mall_id} {code}")
    mall_id, code = args[0], args[1]
    app = load_app()
    auth = basic_auth(app["client_id"], app["client_secret"])
    data = (
        f"grant_type=authorization_code"
        f"&code={urllib.parse.quote(code)}"
        f"&redirect_uri={urllib.parse.quote(app['redirect_uri'])}"
    ).encode()
    req = urllib.request.Request(
        f"https://{mall_id}.cafe24api.com/api/v2/oauth/token",
        data=data, method="POST",
    )
    req.add_header("Authorization", f"Basic {auth}")
    req.add_header("Content-Type", "application/x-www-form-urlencoded")
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            tokens = json.loads(resp.read().decode())
            tokens["obtained_at"] = datetime.now().isoformat()
            tokens["last_refreshed_at"] = datetime.now().isoformat()
            get_store_dir(mall_id)
            save_tokens(mall_id, tokens)
            set_active_mall(mall_id)
            output({
                "status": "ok",
                "mall_id": tokens.get("mall_id", mall_id),
                "scopes": tokens.get("scopes", []),
                "expires_at": tokens.get("expires_at", ""),
            })
    except urllib.error.HTTPError as e:
        body_text = e.read().decode() if e.fp else ""
        output({"error": f"Token exchange failed: HTTP {e.code}", "detail": body_text})


def cmd_refresh(args):
    mall_id = get_active_mall_id()
    if not mall_id:
        fail("No mall configured.")
    app = load_app()
    tokens = load_tokens(mall_id)
    ok, result = do_refresh_token(app, mall_id, tokens)
    if ok:
        warn = check_token_expiry(result)
        resp = {"status": "ok", "message": "Token refreshed successfully"}
        if warn:
            resp["token_warning"] = warn
        output(resp)
    else:
        output(result)


def cmd_token_status(args):
    mall_id = get_active_mall_id()
    if not mall_id:
        fail("No mall configured.")
    tokens = load_tokens(mall_id)
    info = {
        "mall_id": mall_id,
        "has_access_token": bool(tokens.get("access_token")),
        "has_refresh_token": bool(tokens.get("refresh_token")),
        "expires_at": tokens.get("expires_at", ""),
        "refresh_token_expires_at": tokens.get("refresh_token_expires_at", ""),
        "last_refreshed_at": tokens.get("last_refreshed_at", ""),
        "scopes": tokens.get("scopes", []),
    }
    warn = check_token_expiry(tokens)
    if warn:
        info["token_warning"] = warn
    output(info)


# ──────────────────────────────────────────────────────────
# 명령어: 몰 관리
# ──────────────────────────────────────────────────────────

def cmd_malls_list(args):
    malls = []
    active = get_active_mall_id()
    if STORES_DIR.exists():
        for d in sorted(STORES_DIR.iterdir()):
            if d.is_dir() and not d.name.startswith("_"):
                store_file = d / "store.json"
                name = ""
                if store_file.exists():
                    with open(store_file) as f:
                        name = json.load(f).get("store_name", "")
                malls.append({
                    "mall_id": d.name,
                    "store_name": name,
                    "active": d.name == active,
                    "has_tokens": (d / "tokens.json").exists(),
                })
    # 레거시 단일 store.json 호환
    if not malls:
        legacy = CONFIG_DIR / "store.json"
        if legacy.exists():
            with open(legacy) as f:
                data = json.load(f)
                malls.append({
                    "mall_id": data.get("mall_id", ""),
                    "store_name": data.get("store_name", ""),
                    "active": True,
                    "has_tokens": (CONFIG_DIR / "tokens.json").exists(),
                })
    output({"malls": malls, "count": len(malls)})


def cmd_malls_switch(args):
    if not args:
        fail("mall_id required")
    mall_id = args[0]
    store_dir = STORES_DIR / mall_id
    if not store_dir.exists():
        fail(f"Mall '{mall_id}' not found. Use 'malls add {mall_id}' first.")
    set_active_mall(mall_id)
    output({"status": "ok", "active_mall": mall_id})


def cmd_malls_add(args):
    if not args:
        fail("mall_id required")
    mall_id = args[0]
    store_dir = get_store_dir(mall_id)
    store_file = store_dir / "store.json"
    if not store_file.exists():
        save_store(mall_id, {
            "onboarded": False,
            "mall_id": mall_id,
            "store_name": "",
            "mall_domain": "",
            "profile": {},
            "features": {},
            "preferences": {
                "report_time": "09:00",
                "timezone": "Asia/Seoul",
                "inventory_threshold": 5,
            },
            "created_at": datetime.now().isoformat(),
        })
    output({"status": "ok", "mall_id": mall_id, "path": str(store_dir)})


# ──────────────────────────────────────────────────────────
# 명령어: 주문
# ──────────────────────────────────────────────────────────

def cmd_orders(args):
    mall_id = get_active_mall_id()
    tokens = load_tokens(mall_id)
    start, end = parse_date_range(args)
    result = api_call_with_retry(mall_id, tokens, "orders", {
        "start_date": start, "end_date": end, "limit": "100"
    })
    orders = result.get("orders", [])
    summary = {
        "period": f"{start} ~ {end}",
        "total_orders": len(orders),
        "by_status": {},
        "total_amount": 0,
        "orders": []
    }
    for o in orders:
        status = o.get("order_status", "unknown")
        summary["by_status"][status] = summary["by_status"].get(status, 0) + 1
        amount = float(o.get("total_amount_due", 0) or 0)
        summary["total_amount"] += amount
        entry = {
            "order_id": o.get("order_id"),
            "buyer_name": o.get("buyer_name", ""),
            "status": status,
            "amount": amount,
            "order_date": o.get("order_date", ""),
        }
        summary["orders"].append(mask_dict(entry))
    warn = check_token_expiry(tokens)
    if warn:
        summary["token_warning"] = warn
    output(summary)


def cmd_orders_count(args):
    mall_id = get_active_mall_id()
    tokens = load_tokens(mall_id)
    start, end = parse_date_range(args)
    result = api_call_with_retry(mall_id, tokens, "orders/count", {
        "start_date": start, "end_date": end
    })
    output(result)


def cmd_order_detail(args):
    if not args:
        fail("order_id required")
    mall_id = get_active_mall_id()
    tokens = load_tokens(mall_id)
    result = api_call_with_retry(mall_id, tokens, f"orders/{args[0]}")
    if "order" in result:
        result["order"] = mask_dict(result["order"])
    output(result)


# ──────────────────────────────────────────────────────────
# 명령어: 매출
# ──────────────────────────────────────────────────────────

def cmd_sales(args):
    mall_id = get_active_mall_id()
    tokens = load_tokens(mall_id)
    start, end = parse_date_range(args)
    result = api_call_with_retry(mall_id, tokens, "reports/dailysales", {
        "start_date": start, "end_date": end
    })
    output(result)


# ──────────────────────────────────────────────────────────
# 명령어: 상품
# ──────────────────────────────────────────────────────────

def cmd_products(args):
    mall_id = get_active_mall_id()
    tokens = load_tokens(mall_id)
    limit = "20"
    offset = "0"
    i = 0
    while i < len(args):
        if args[i] == "--limit" and i + 1 < len(args):
            limit = args[i + 1]; i += 2
        elif args[i] == "--offset" and i + 1 < len(args):
            offset = args[i + 1]; i += 2
        else:
            i += 1
    result = api_call_with_retry(mall_id, tokens, "products", {
        "limit": limit, "offset": offset
    })
    products = result.get("products", [])
    items = []
    for p in products:
        items.append({
            "product_no": p.get("product_no"),
            "product_name": p.get("product_name", ""),
            "price": p.get("price", ""),
            "display": p.get("display", ""),
            "selling": p.get("selling", ""),
            "sold_out": p.get("sold_out", ""),
            "created_date": p.get("created_date", ""),
        })
    output({"count": len(items), "offset": int(offset), "products": items})


def cmd_product_detail(args):
    if not args:
        fail("product_no required")
    mall_id = get_active_mall_id()
    tokens = load_tokens(mall_id)
    result = api_call_with_retry(mall_id, tokens, f"products/{args[0]}")
    output(result)


# ──────────────────────────────────────────────────────────
# 명령어: 재고
# ──────────────────────────────────────────────────────────

def cmd_inventory(args):
    mall_id = get_active_mall_id()
    tokens = load_tokens(mall_id)
    store = load_store(mall_id)
    threshold = int(args[0]) if args else store.get("preferences", {}).get("inventory_threshold", 5)

    products = api_list_all(mall_id, tokens, "products", "products", {
        "display": "T", "selling": "T"
    })

    low_stock = []
    for p in products:
        product_no = p.get("product_no")
        time.sleep(RATE_LIMIT_DELAY)
        variants = api_call_with_retry(mall_id, tokens, f"products/{product_no}/variants")
        for v in variants.get("variants", []):
            qty = int(v.get("quantity", 0))
            if qty <= threshold:
                low_stock.append({
                    "product_no": product_no,
                    "product_name": p.get("product_name", ""),
                    "variant": v.get("option_value", ""),
                    "quantity": qty,
                })

    output({
        "threshold": threshold,
        "products_checked": len(products),
        "low_stock_count": len(low_stock),
        "items": low_stock
    })


# ──────────────────────────────────────────────────────────
# 명령어: 고객
# ──────────────────────────────────────────────────────────

def cmd_customers_count(args):
    mall_id = get_active_mall_id()
    tokens = load_tokens(mall_id)
    result = api_call_with_retry(mall_id, tokens, "customers/count")
    output(result)


def cmd_customer_groups(args):
    mall_id = get_active_mall_id()
    tokens = load_tokens(mall_id)
    result = api_call_with_retry(mall_id, tokens, "customergroups")
    output(result)


def cmd_customer_detail(args):
    if not args:
        fail("member_id required")
    mall_id = get_active_mall_id()
    tokens = load_tokens(mall_id)
    result = api_call_with_retry(mall_id, tokens, f"customers/{args[0]}")
    if "customer" in result:
        result["customer"] = mask_dict(result["customer"])
    output(result)


# ──────────────────────────────────────────────────────────
# 명령어: 쿠폰
# ──────────────────────────────────────────────────────────

def cmd_coupons_list(args):
    mall_id = get_active_mall_id()
    tokens = load_tokens(mall_id)
    result = api_call_with_retry(mall_id, tokens, "coupons")
    output(result)


def cmd_coupon_create(args):
    if not args:
        fail("JSON file path required. Usage: coupon-create /path/to/coupon.json")
    json_file = Path(args[0])
    if not json_file.exists():
        fail(f"File not found: {args[0]}")
    with open(json_file) as f:
        body = json.load(f)
    mall_id = get_active_mall_id()
    tokens = load_tokens(mall_id)
    result = api_call_with_retry(mall_id, tokens, "coupons", method="POST", body={"coupon": body})
    output(result)


# ──────────────────────────────────────────────────────────
# 명령어: 배송
# ──────────────────────────────────────────────────────────

def cmd_shipment_create(args):
    if len(args) < 2:
        fail("Usage: shipment-create {order_id} {json_file}")
    order_id = args[0]
    json_file = Path(args[1])
    if not json_file.exists():
        fail(f"File not found: {args[1]}")
    with open(json_file) as f:
        body = json.load(f)
    mall_id = get_active_mall_id()
    tokens = load_tokens(mall_id)
    result = api_call_with_retry(mall_id, tokens, f"orders/{order_id}/shipments",
                                  method="POST", body={"shipment": body})
    output(result)


def cmd_shipping_carriers(args):
    mall_id = get_active_mall_id()
    tokens = load_tokens(mall_id)
    result = api_call_with_retry(mall_id, tokens, "shippingcarriers")
    output(result)


# ──────────────────────────────────────────────────────────
# 명령어: 게시판
# ──────────────────────────────────────────────────────────

def cmd_boards_list(args):
    mall_id = get_active_mall_id()
    tokens = load_tokens(mall_id)
    result = api_call_with_retry(mall_id, tokens, "boards")
    output(result)


def cmd_board_articles(args):
    if not args:
        fail("board_no required")
    mall_id = get_active_mall_id()
    tokens = load_tokens(mall_id)
    result = api_call_with_retry(mall_id, tokens, f"boards/{args[0]}/articles")
    output(result)


# ──────────────────────────────────────────────────────────
# 명령어: 적립금
# ──────────────────────────────────────────────────────────

def cmd_mileage(args):
    if not args:
        fail("member_id required")
    mall_id = get_active_mall_id()
    tokens = load_tokens(mall_id)
    result = api_call_with_retry(mall_id, tokens, f"customers/{args[0]}/mileage")
    output(result)


def cmd_mileage_give(args):
    if len(args) < 3:
        fail("Usage: mileage-give {member_id} {amount} {reason}")
    member_id, amount, reason = args[0], args[1], " ".join(args[2:])
    mall_id = get_active_mall_id()
    tokens = load_tokens(mall_id)
    result = api_call_with_retry(mall_id, tokens, f"customers/{member_id}/mileage",
                                  method="POST", body={
                                      "mileage": {"amount": int(amount), "reason": reason}
                                  })
    output(result)


# ──────────────────────────────────────────────────────────
# 명령어: 모니터링
# ──────────────────────────────────────────────────────────

def cmd_store_info(args):
    mall_id = get_active_mall_id()
    tokens = load_tokens(mall_id)
    result = api_call_with_retry(mall_id, tokens, "store")
    output(result)


def cmd_healthcheck(args):
    mall_id = get_active_mall_id()
    store = load_store(mall_id)
    domain = store.get("mall_domain", f"{mall_id}.cafe24.com")
    url = f"https://{domain}"
    try:
        start_time = datetime.now()
        req = urllib.request.Request(url)
        req.add_header("User-Agent", "OpenClaw-HealthCheck/1.0")
        with urllib.request.urlopen(req, timeout=10) as resp:
            elapsed = (datetime.now() - start_time).total_seconds()
            output({
                "status": "ok", "url": url,
                "http_code": resp.status,
                "response_time_seconds": round(elapsed, 2),
            })
    except Exception as e:
        output({"status": "down", "url": url, "error": str(e)})


# ──────────────────────────────────────────────────────────
# 명령어 라우터
# ──────────────────────────────────────────────────────────

COMMANDS = {
    # 온보딩
    "auth-url": cmd_auth_url,
    "exchange-code": cmd_exchange_code,
    "refresh-token": cmd_refresh,
    "token-status": cmd_token_status,
    # 몰 관리
    "malls": None,  # 서브커맨드로 분기
    # 주문
    "orders": cmd_orders,
    "orders-count": cmd_orders_count,
    "order-detail": cmd_order_detail,
    # 매출
    "sales": cmd_sales,
    # 상품
    "products": cmd_products,
    "product-detail": cmd_product_detail,
    # 재고
    "inventory": cmd_inventory,
    # 고객
    "customers-count": cmd_customers_count,
    "customer-groups": cmd_customer_groups,
    "customer-detail": cmd_customer_detail,
    # 쿠폰
    "coupons-list": cmd_coupons_list,
    "coupon-create": cmd_coupon_create,
    # 배송
    "shipment-create": cmd_shipment_create,
    "shipping-carriers": cmd_shipping_carriers,
    # 게시판
    "boards-list": cmd_boards_list,
    "board-articles": cmd_board_articles,
    # 적립금
    "mileage": cmd_mileage,
    "mileage-give": cmd_mileage_give,
    # 모니터링
    "store-info": cmd_store_info,
    "healthcheck": cmd_healthcheck,
}

MALLS_SUBCOMMANDS = {
    "list": cmd_malls_list,
    "switch": cmd_malls_switch,
    "add": cmd_malls_add,
}


def main():
    argv = sys.argv[1:]
    if not argv or argv[0] in ("-h", "--help"):
        print(__doc__)
        sys.exit(0)

    # 글로벌 옵션 파싱
    remaining = []
    i = 0
    while i < len(argv):
        if argv[i] == "--mall" and i + 1 < len(argv):
            OPTS["mall"] = argv[i + 1]; i += 2
        elif argv[i] == "--mask":
            OPTS["mask"] = True; i += 1
        elif argv[i] == "--send":
            OPTS["send"] = True; i += 1
        else:
            remaining.append(argv[i]); i += 1

    if not remaining:
        print(__doc__)
        sys.exit(0)

    cmd = remaining[0]
    args = remaining[1:]

    # malls 서브커맨드 분기
    if cmd == "malls":
        sub = args[0] if args else "list"
        sub_args = args[1:] if len(args) > 1 else []
        if sub not in MALLS_SUBCOMMANDS:
            fail(f"Unknown malls subcommand: {sub}. Available: {list(MALLS_SUBCOMMANDS.keys())}")
        MALLS_SUBCOMMANDS[sub](sub_args)
        return

    if cmd not in COMMANDS:
        fail(f"Unknown command: {cmd}. Available: {list(COMMANDS.keys())}")

    COMMANDS[cmd](args)


if __name__ == "__main__":
    main()

---
name: cafe24-assistant
description: 카페24 쇼핑몰 API 연동 및 운영 자동화. 주문 조회, 매출 리포트, 재고 알림, 상품 관리, 고객 관리, 쿠폰, 배송을 대화형으로 처리. OAuth 온보딩, 토큰 관리, 멀티몰 지원 포함. 사용자가 쇼핑몰 관련 질문이나 요청을 할 때 사용.
metadata: {"openclaw":{"emoji":"🛒","requires":{"bins":["python3"]}}}
user-invocable: true
disable-model-invocation: false
---

# 카페24 쇼핑몰 어시스턴트

## 핵심 규칙

모든 카페24 API 호출은 반드시 cafe24-api.py를 통해서만 실행한다.
curl, heredoc, python one-liner 사용 금지 — exec 보안 필터에 걸린다.

```bash
python3 /data/scripts/cafe24-api.py [--mall MALL_ID] [--mask] [--send] COMMAND [ARGS...]
```

## 글로벌 옵션

| 옵션 | 설명 |
|------|------|
| `--mall MALL_ID` | 특정 몰 지정 (생략 시 기본 몰) |
| `--mask` | 개인정보 마스킹 (전화번호, 주소, 이메일) |
| `--send` | 결과를 텔레그램으로 직접 전송 |

## 명령어 목록

### 온보딩
| 명령 | 설명 |
|------|------|
| `auth-url {mall_id}` | OAuth 인증 URL 생성 |
| `exchange-code {mall_id} {code}` | code → 토큰 교환 (1분 내 실행 필수) |
| `refresh-token` | access_token 갱신 |
| `token-status` | 토큰 상태 및 만료일 확인 |

### 몰 관리 (멀티몰)
| 명령 | 설명 |
|------|------|
| `malls list` | 등록된 몰 목록 |
| `malls switch {mall_id}` | 기본 몰 변경 |
| `malls add {mall_id}` | 새 몰 등록 |

### 주문
| 명령 | 설명 |
|------|------|
| `orders [today\|yesterday\|날짜\|시작 끝]` | 주문 목록 + 요약 |
| `orders-count [today\|yesterday\|날짜]` | 주문 건수만 |
| `order-detail {order_id}` | 주문 상세 |

### 매출
| 명령 | 설명 |
|------|------|
| `sales [today\|yesterday\|week\|month\|시작 끝]` | 매출 리포트 |

### 상품/재고
| 명령 | 설명 |
|------|------|
| `products [--limit N] [--offset N]` | 상품 목록 |
| `product-detail {product_no}` | 상품 상세 |
| `inventory [threshold]` | 재고 부족 상품 (기본 5개 이하) |

### 고객
| 명령 | 설명 |
|------|------|
| `customers-count` | 회원 수 |
| `customer-groups` | 등급별 분류 |
| `customer-detail {member_id}` | 회원 상세 |

### 쿠폰/프로모션
| 명령 | 설명 |
|------|------|
| `coupons-list` | 쿠폰 목록 |
| `coupon-create {json_file}` | 쿠폰 생성 (확인 후) |

### 배송
| 명령 | 설명 |
|------|------|
| `shipment-create {order_id} {json_file}` | 송장 등록 (확인 후) |
| `shipping-carriers` | 택배사 목록 |

### 게시판
| 명령 | 설명 |
|------|------|
| `boards-list` | 게시판 목록 |
| `board-articles {board_no}` | 게시물 조회 |

### 적립금
| 명령 | 설명 |
|------|------|
| `mileage {member_id}` | 적립금 조회 |
| `mileage-give {member_id} {amount} {reason}` | 적립금 지급 (확인 후) |

### 모니터링
| 명령 | 설명 |
|------|------|
| `store-info` | 쇼핑몰 정보 |
| `healthcheck` | 사이트 상태 |

## 파괴적 작업 (반드시 사용자 확인 후)

coupon-create, mileage-give, shipment-create — 실행 전 반드시 확인 받고, 실행 후 결과 보고.

## 보안 규칙

- 토큰, client_secret 값을 대화에 절대 노출하지 않는다.
- 고객 개인정보 조회 시 `--mask` 옵션을 사용한다.
- 401 → 자동 토큰 갱신. 429 → 자동 재시도 (최대 3회).

## 상세 레퍼런스

필요할 때만 읽는다:
- 온보딩 상세 플로우 → `references/onboarding.md`
- API 엔드포인트 전체 목록 → `references/api.md`
- 주문/상품/고객 데이터 모델 → `references/data-models.md`
- 에러 코드 및 Rate Limit → `references/errors-and-limits.md`

# 카페24 API 엔드포인트 레퍼런스

Base URL: `https://{mall_id}.cafe24api.com/api/v2/admin`

## 인증

- 방식: OAuth 2.0 Authorization Code Grant
- 토큰 유효기간: Access Token ~2시간, Refresh Token ~14일
- Rate Limit: 초당 2회
- 필수 헤더: Authorization, Content-Type, X-Cafe24-Api-Version

## 보유 권한 (전체 스코프)

| 도메인 | read | write | 대상 |
|--------|------|-------|------|
| 상품분류 | mall.read_category | mall.write_category | 카테고리, 메인진열 |
| 상품 | mall.read_product | mall.write_product | 상품 정보 전체 |
| 컬렉션 | mall.read_collection | mall.write_collection | 브랜드, 자체분류 |
| 공급사 | mall.read_supply | mall.write_supply | 공급사 정보 |
| 주문 | mall.read_order | mall.write_order | 주문 조회/수정 |
| 커뮤니티 | mall.read_community | mall.write_community | 게시판, 게시물 |
| 고객 | mall.read_customer | mall.write_customer | 회원, 등급 |
| 알림 | mall.read_notification | mall.write_notification | 메시지 |
| 쇼핑몰 설정 | mall.read_store | mall.write_store | 상점 설정 |
| 프로모션 | mall.read_promotion | mall.write_promotion | 쿠폰, 혜택 |
| 디자인 | mall.read_design | mall.write_design | 테마, 페이지 |
| 매출통계 | mall.read_salesreport | mall.write_salesreport | 매출 리포트 |
| 적립금 | mall.read_mileage | mall.write_mileage | 적립금, 예치금 |
| 배송 | mall.read_shipping | mall.write_shipping | 배송, 반품 |

## 주요 엔드포인트

### 쇼핑몰
| 메서드 | 경로 | 설명 |
|--------|------|------|
| GET | /store | 쇼핑몰 기본 정보 |

### 주문
| 메서드 | 경로 | 설명 |
|--------|------|------|
| GET | /orders | 주문 목록 (start_date, end_date 필수) |
| GET | /orders/{order_id} | 주문 상세 |
| GET | /orders/count | 주문 건수 |
| GET | /orders/{order_id}/items | 주문 상품 |

주문 상태: N00=입금전, N10=결제완료, N20=상품준비중, N30=배송준비중, N40=배송중, N50=배송완료, C00=취소신청, C10=취소완료, R00=반품신청, R10=반품완료

### 상품
| 메서드 | 경로 | 설명 |
|--------|------|------|
| GET | /products | 상품 목록 |
| GET | /products/{product_no} | 상품 상세 |
| GET | /products/count | 상품 수 |
| GET | /products/{product_no}/variants | 품목별 재고 |

### 매출/통계
| 메서드 | 경로 | 설명 |
|--------|------|------|
| GET | /reports/dailysales | 일별 매출 |
| GET | /reports/productsales | 상품별 매출 |

### 고객
| 메서드 | 경로 | 설명 |
|--------|------|------|
| GET | /customers | 회원 목록 |
| GET | /customers/{member_id} | 회원 상세 |
| GET | /customers/count | 회원 수 |
| GET | /customergroups | 회원 등급 |
| GET | /customers/{member_id}/mileage | 적립금 조회 |
| POST | /customers/{member_id}/mileage | 적립금 지급 |

### 배송
| 메서드 | 경로 | 설명 |
|--------|------|------|
| POST | /orders/{order_id}/shipments | 송장 등록 |
| GET | /shippingcarriers | 택배사 목록 |

택배사: 0001=CJ대한통운, 0002=우체국, 0003=한진, 0004=로젠, 0005=롯데

### 쿠폰
| 메서드 | 경로 | 설명 |
|--------|------|------|
| GET | /coupons | 쿠폰 목록 |
| POST | /coupons | 쿠폰 발행 |

### 게시판
| 메서드 | 경로 | 설명 |
|--------|------|------|
| GET | /boards | 게시판 목록 |
| GET | /boards/{board_no}/articles | 게시물 목록 |

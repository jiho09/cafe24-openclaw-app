# 온보딩 플로우 상세

## OAuth 인증 흐름

```
고객 브라우저 → 카페24 (인증+승인)
카페24 → 정적 콜백 페이지 (code 전달, 302 redirect)
콜백 페이지 → 고객 (URL 표시, 복사 유도)
고객 → 텔레그램 (URL 붙여넣기)
에이전트 → 카페24 (code→token 교환, 아웃바운드 POST)
```

토큰 교환은 아웃바운드 요청이므로 고객 서버 방화벽과 무관하게 동작.

## 에이전트 동작 순서

### 1. 인증 URL 생성

고객이 mall_id를 알려주면:
```bash
python3 /data/scripts/cafe24-api.py auth-url {mall_id}
```
반환된 URL을 고객에게 전송.

### 2. 코드 수신 및 토큰 교환

고객이 콜백 URL을 붙여넣으면:
1. URL에서 `code` 파라미터 추출 (예: `?code=AbCdEf&state=xxx` → `AbCdEf`)
2. 즉시 실행 (코드는 1분 내 만료):
```bash
python3 /data/scripts/cafe24-api.py exchange-code {mall_id} {code}
```
3. 성공하면 tokens.json 자동 저장, 기본 몰로 설정됨.

### 3. 연결 확인

토큰 교환 성공 후:
```bash
python3 /data/scripts/cafe24-api.py store-info
```
쇼핑몰 이름이 나오면 연결 완료.

## 주의사항

- authorization code는 1회용. 재사용 불가.
- 카페24 스코프 구분자는 쉼표(`,`). cafe24-api.py가 자동 처리.
- Basic Auth 방식으로 토큰 교환 (client_id:client_secret → base64).
- 교환 실패 시 새 인증 URL을 재생성해야 함.

## 재연동 (토큰 만료 시)

refresh_token 갱신 실패 시:
1. `auth-url`로 새 인증 URL 생성
2. 고객에게 재연동 링크 전송
3. 동일한 code 수신 → 교환 플로우 반복

## 토큰 자동 갱신 Cron

연동 완료 후 12시간마다 토큰 갱신 Cron 등록:
- 명령: `python3 /data/scripts/cafe24-api.py refresh-token`
- refresh_token 만료 5일 전부터 경고 메시지 출력

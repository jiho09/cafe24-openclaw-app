# 에러 코드 및 Rate Limit

## HTTP 에러 코드

| 코드 | 의미 | cafe24-api.py 대응 |
|------|------|-------------------|
| 200 | 성공 | 정상 처리 |
| 401 | 인증 만료 | 자동 토큰 갱신 후 재시도 |
| 403 | 권한 없음 | 필요한 scope 안내 |
| 404 | 리소스 없음 | 입력값 확인 요청 |
| 429 | Rate Limit | 1초 대기 후 자동 재시도 (최대 3회) |
| 500 | 서버 오류 | 재시도, 지속 시 카페24 상태 확인 안내 |

## Rate Limit

- 기본 제한: 초당 2회
- cafe24-api.py 내부 호출 간격: 0.6초
- 429 발생 시: 1초 → 2초 → 3초 대기 후 재시도
- 페이지네이션 시 자동 delay 적용

## 토큰 만료

| 토큰 | 유효기간 | 만료 시 |
|------|---------|---------|
| access_token | ~2시간 | 자동 갱신 (401 감지) |
| refresh_token | ~14일 | 재연동 필요 (OAuth 플로우 재실행) |

## token-status 경고 기준

| 잔여일 | 경고 수준 |
|--------|----------|
| 5일 이하 | "재연동 준비 필요" |
| 2일 이하 | "즉시 재연동 필요!" |

## 흔한 실패 원인

| 증상 | 원인 | 해결 |
|------|------|------|
| "Token exchange failed: HTTP 401" | authorization code 만료 (1분 초과) | 새 인증 URL 재생성 |
| "Token exchange failed: HTTP 400" | code 재사용 또는 redirect_uri 불일치 | 새 인증 URL 재생성 |
| "Token refresh failed: HTTP 401" | refresh_token 만료 (14일 초과) | 재연동 플로우 실행 |
| "HTTP 403" | 해당 scope 미보유 | 앱 권한 확인 |
| orders 조회 결과 빈 배열 | start_date/end_date 누락 또는 범위 밖 | 날짜 범위 확인 |

#!/usr/bin/env python3
"""
카페24 어시스턴트 설치 스크립트

사용법:
  python3 setup.py              ← zip과 같은 폴더에서 실행
  python3 setup.py /path/to/    ← 압축 해제된 폴더 경로 지정

이 스크립트가 하는 일:
  1. scripts/cafe24-api.py → /data/scripts/
  2. config/app.json → /data/config/
  3. soul/ 파일들 → ~/.openclaw/workspace/
  4. skills/ → ~/.openclaw/workspace/skills/
  5. templates/ → /data/templates/
"""

import shutil
import sys
import os
from pathlib import Path

# 설치 소스 디렉토리 결정
if len(sys.argv) > 1:
    SRC = Path(sys.argv[1])
else:
    SRC = Path(__file__).parent

WORKSPACE = Path.home() / ".openclaw" / "workspace"
DATA = Path("/data")

PLAN = [
    # (소스, 대상, 설명)
    ("scripts/cafe24-api.py", DATA / "scripts" / "cafe24-api.py", "API 헬퍼 스크립트"),
    ("config/app.json", DATA / "config" / "app.json", "앱 인증 설정"),
    ("soul/SOUL.md", WORKSPACE / "SOUL.md", "에이전트 성격"),
    ("soul/AGENTS.md", WORKSPACE / "AGENTS.md", "운영 규칙"),
    ("soul/TOOLS.md", WORKSPACE / "TOOLS.md", "도구 레퍼런스"),
    ("skills/cafe24-assistant/SKILL.md",
     WORKSPACE / "skills" / "cafe24-assistant" / "SKILL.md", "스킬 정의"),
    ("skills/cafe24-assistant/references/onboarding.md",
     WORKSPACE / "skills" / "cafe24-assistant" / "references" / "onboarding.md", "온보딩 상세"),
    ("skills/cafe24-assistant/references/api.md",
     WORKSPACE / "skills" / "cafe24-assistant" / "references" / "api.md", "API 레퍼런스"),
    ("skills/cafe24-assistant/references/data-models.md",
     WORKSPACE / "skills" / "cafe24-assistant" / "references" / "data-models.md", "데이터 모델"),
    ("skills/cafe24-assistant/references/errors-and-limits.md",
     WORKSPACE / "skills" / "cafe24-assistant" / "references" / "errors-and-limits.md", "에러/Rate Limit"),
    ("templates/daily-report.md", DATA / "templates" / "daily-report.md", "일일 리포트 템플릿"),
    ("templates/inventory-alert.md", DATA / "templates" / "inventory-alert.md", "재고 알림 템플릿"),
]


def install():
    installed = []
    skipped = []
    errors = []

    for rel, dest, desc in PLAN:
        src = SRC / rel
        if not src.exists():
            skipped.append(f"  - {rel} (파일 없음)")
            continue
        try:
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(str(src), str(dest))
            installed.append(f"  - {desc}: {dest}")
        except Exception as e:
            errors.append(f"  - {rel}: {e}")

    print("=== 카페24 어시스턴트 설치 완료 ===")
    print()
    if installed:
        print(f"설치됨 ({len(installed)}개):")
        print("\n".join(installed))
    if skipped:
        print(f"\n건너뜀 ({len(skipped)}개):")
        print("\n".join(skipped))
    if errors:
        print(f"\n오류 ({len(errors)}개):")
        print("\n".join(errors))
    print()
    print("다음 단계: 텔레그램에서 아무 메시지나 보내면 온보딩이 시작됩니다.")


if __name__ == "__main__":
    install()

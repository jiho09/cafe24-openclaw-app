# {store_name} 일일 리포트

날짜: {date}

## 매출 현황
- 총 매출: {total_sales}원
- 주문 건수: {order_count}건
- 평균 주문액: {avg_order}원
- 전일 대비: {daily_change}

## 주문 상태별 현황
- 결제완료 (처리 필요): {status_n10}건
- 상품준비중: {status_n20}건
- 배송중: {status_n40}건
- 배송완료: {status_n50}건
- 취소/반품: {status_cancel}건

## 주의 사항
{alerts}

---

## 변수 매핑 가이드 (에이전트용)

이 템플릿은 에이전트가 cafe24-api.py 결과를 조합하여 채운다.

| 변수 | 소스 명령 | 필드 |
|------|----------|------|
| {store_name} | store.json | store_name |
| {date} | 어제 날짜 (YYYY-MM-DD) | 계산 |
| {total_sales} | `sales yesterday` | dailysales 합계 |
| {order_count} | `orders yesterday` | total_orders |
| {avg_order} | total_sales / order_count | 계산 |
| {daily_change} | 전일 매출 비교 | 계산 (2일치 sales 조회) |
| {status_n10} | `orders yesterday` | by_status["N10"] |
| {status_n20} | `orders yesterday` | by_status["N20"] |
| {status_n40} | `orders yesterday` | by_status["N40"] |
| {status_n50} | `orders yesterday` | by_status["N50"] |
| {status_cancel} | `orders yesterday` | by_status["C00"] + by_status["C10"] |
| {alerts} | `inventory` + `token-status` | 재고 부족 + 토큰 만료 경고 |

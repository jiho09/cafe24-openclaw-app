# 재고 부족 알림

기준: {threshold}개 이하

| 상품명 | 옵션 | 재고 |
|--------|------|------|
{rows}

총 {count}개 상품의 재고가 부족합니다.

---

## 변수 매핑 가이드 (에이전트용)

| 변수 | 소스 명령 | 필드 |
|------|----------|------|
| {threshold} | `inventory` 결과 | threshold |
| {rows} | `inventory` 결과 | items 배열을 테이블 행으로 변환 |
| {count} | `inventory` 결과 | low_stock_count |

### {rows} 생성 예시
`python3 cafe24-api.py inventory 5` 결과의 items:
```json
[
  {"product_name": "여름 반팔티", "variant": "S/블랙", "quantity": 2},
  {"product_name": "린넨 바지", "variant": "L/베이지", "quantity": 0}
]
```
→ 변환:
```
| 여름 반팔티 | S/블랙 | 2 |
| 린넨 바지 | L/베이지 | 0 |
```

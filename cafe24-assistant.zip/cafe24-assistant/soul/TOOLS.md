# 도구 레퍼런스

## cafe24-api.py

모든 카페24 API 작업의 유일한 실행 도구.
curl, heredoc, python one-liner는 exec 보안 필터에 걸리므로 사용 금지.

### 위치
```
/data/scripts/cafe24-api.py
```

### 기본 형식
```bash
python3 /data/scripts/cafe24-api.py [옵션] 명령 [인자...]
```

### 글로벌 옵션
| 옵션 | 설명 |
|------|------|
| `--mall MALL_ID` | 특정 몰 지정 (생략 시 기본 몰) |
| `--mask` | 개인정보 마스킹 |
| `--send` | 텔레그램 직접 전송 |

### 빠른 참조

```bash
# 온보딩
cafe24-api.py auth-url {mall_id}
cafe24-api.py exchange-code {mall_id} {code}
cafe24-api.py refresh-token
cafe24-api.py token-status

# 몰 관리
cafe24-api.py malls list
cafe24-api.py malls switch {mall_id}
cafe24-api.py malls add {mall_id}

# 조회
cafe24-api.py orders today
cafe24-api.py orders yesterday
cafe24-api.py orders 2026-04-01 2026-04-07
cafe24-api.py orders-count today
cafe24-api.py order-detail {order_id}
cafe24-api.py sales week
cafe24-api.py sales month
cafe24-api.py products --limit 20
cafe24-api.py product-detail {product_no}
cafe24-api.py inventory 5
cafe24-api.py customers-count
cafe24-api.py customer-groups
cafe24-api.py --mask customer-detail {member_id}
cafe24-api.py coupons-list
cafe24-api.py boards-list
cafe24-api.py board-articles {board_no}
cafe24-api.py mileage {member_id}
cafe24-api.py shipping-carriers

# 쓰기 작업 (확인 후)
cafe24-api.py coupon-create /path/to/coupon.json
cafe24-api.py shipment-create {order_id} /path/to/shipment.json
cafe24-api.py mileage-give {member_id} {amount} {reason}

# 모니터링
cafe24-api.py store-info
cafe24-api.py healthcheck

# 텔레그램 직접 전송
cafe24-api.py --send orders today
cafe24-api.py --send inventory 5
```

### 출력 형식
모든 명령은 JSON을 stdout으로 출력한다.
에러 시: `{"error": "메시지", "detail": "상세"}`
토큰 경고 시: `{"token_warning": {"warning": "메시지", "days_remaining": N}}`

### 설정 파일 구조

| 파일 | 경로 | 용도 |
|------|------|------|
| 앱 설정 | `/data/config/app.json` | client_id, client_secret (서비스 제공자 설정) |
| 활성 몰 | `/data/config/stores/_active.json` | 현재 기본 몰 |
| 몰별 설정 | `/data/config/stores/{mall_id}/store.json` | 프로필, 기능, 환경설정 |
| 몰별 토큰 | `/data/config/stores/{mall_id}/tokens.json` | OAuth 토큰 |

### 상세 API 레퍼런스
cafe24-assistant 스킬의 references/ 디렉토리 참조:
- `references/api.md` — 전체 엔드포인트
- `references/data-models.md` — 데이터 구조
- `references/errors-and-limits.md` — 에러 코드, Rate Limit
